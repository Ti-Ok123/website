import sqlite3

# Verbindung zur Datenbank erstellen (erstellt die Datei, falls sie nicht existiert)
connection = sqlite3.connect("music_shop.db")
cursor = connection.cursor()

# Tabellen erstellen
cursor.execute("""
CREATE TABLE artists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    bio TEXT,
    image_path TEXT
);
""")

cursor.execute("""
CREATE TABLE music (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    genre TEXT,
    artist_id INTEGER,
    file_path TEXT,
    FOREIGN KEY (artist_id) REFERENCES artists (id)
);
""")

# Datenbank speichern und Verbindung schließen
connection.commit()
connection.close()

print("Datenbank wurde erfolgreich erstellt.")
