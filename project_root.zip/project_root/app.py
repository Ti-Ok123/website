from flask import Flask, render_template, request, jsonify, session
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecretkey"

def get_db_connection():
    conn = sqlite3.connect("users.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/genres.html")
def genres():
    return render_template("genres.html")

@app.route("/index.html")
def index():
    return render_template("index.html")
    
@app.route("/loginNew.html")
def login1():
    return render_template("loginNew.html")
    
@app.route("/profile.html")
def profile():
    return render_template("profile.html")

@app.route("/artists.html")
def artists():
    return render_template("artists.html")

@app.route("/library.html")
def library():
    return render_template("library.html")
    
@app.route("/premium.html")
def premium1():
    return render_template("premium.html")

@app.route("/status", methods=["GET"])
def status():
    if "user" in session:
        return jsonify({"logged_in": True, "username": session["user"]})
    return jsonify({"logged_in": False})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE username = ? AND password = ?",
                        (data["username"], data["password"])).fetchone()
    conn.close()
    if user:
        session["user"] = data["username"]
        return jsonify({"success": True, "message": "Erfolgreich angemeldet"})
    return jsonify({"success": False, "message": "Ungültige Anmeldedaten"})

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    conn = get_db_connection()
    # Überprüfen, ob der Benutzername bereits existiert
    existing_user = conn.execute("SELECT * FROM users WHERE username = ?", (data["username"],)).fetchone()
    if existing_user:
        return jsonify({"success": False, "message": "Benutzername bereits vergeben"}), 400
        
    conn.execute("INSERT INTO users (username, password, premium) VALUES (?, ?, ?)",
                 (data["username"], data["password"], False))
    conn.commit()
    conn.close()
    return jsonify({"success": True, "message": "Benutzer erfolgreich registriert"})

@app.route("/change-password", methods=["POST"])
def change_password():
    if "user" not in session:
        return jsonify({"success": False, "message": "Nicht angemeldet"}), 401

    data = request.json
    db = get_db_connection()
    current_password = data.get("currentPassword")
    new_password = data.get("newPassword")

    # Benutzerinformationen aus der Session abrufen
    username = session["user"]

    # Benutzer aus der Datenbank holen
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

    if not user:
        return jsonify({"success": False, "message": "Benutzer nicht gefunden"}), 404

    # Überprüfen, ob das aktuelle Passwort übereinstimmt
    if user["password"] != current_password:
        return jsonify({"success": False, "message": "Aktuelles Passwort ist falsch"}), 400

    # Neues Passwort aktualisieren
    db.execute("UPDATE users SET password = ? WHERE username = ?", (new_password, username))
    db.commit()

    return jsonify({"success": True, "message": "Passwort erfolgreich geändert"})

@app.route("/logout", methods=["POST"])
def logout():
    session.pop("user", None)
    return jsonify({"success": True, "message": "Erfolgreich abgemeldet!"})

@app.route("/premium", methods=["GET"])
def premium():
    conn = get_db_connection()
    if "user" in session:
        username = session["user"]
    
        premium = conn.execute("SELECT premium FROM users WHERE username = ?", (username,)).fetchone()
        return jsonify({"premium": premium["premium"]})
    return jsonify({"premium": 2}) #wenn nicht angemeldet

if __name__ == "__main__":
    app.run(debug=True)
