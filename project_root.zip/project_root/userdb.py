import sqlite3

# Datenbank und Tabelle erstellen
connection = sqlite3.connect("users.db")
cursor = connection.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    premium BOOLEAN NOT NULL
);
""")

connection.commit()
connection.close()
print("Datenbank wurde erfolgreich erstellt.")
