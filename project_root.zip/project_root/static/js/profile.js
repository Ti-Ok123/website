document.addEventListener("DOMContentLoaded", async () => {
  const usernameSpan = document.getElementById("username");
  const emailSpan = document.getElementById("email");
  const logoutButton = document.getElementById("logoutButton");
  const feedbackDiv = document.getElementById("feedback");

  // Benutzerinformationen abrufen
  try {
    const response = await fetch("/status", {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    const data = await response.json();
      usernameSpan.textContent = data.username;
  } catch (error) {
    console.error("Fehler beim Abrufen der Profilinformationen:", error);
  }

  // Passwort ändern
  const passwordChangeForm = document.getElementById("passwordChangeForm");

  passwordChangeForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

      const currentPasswordInput = document.getElementById("currentPassword");
    const newPasswordInput = document.getElementById("newPassword");
    const confirmPasswordInput = document.getElementById("confirmPassword");

    if (newPassword !== confirmPassword) {
      feedbackDiv.textContent = "Die neuen Passwörter stimmen nicht überein.";
      feedbackDiv.className = "error";
      feedbackDiv.style.display = "block";
      return;
    }

    try {
      const response = await fetch("/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      const result = await response.json();
      if (result.success) {
        feedbackDiv.textContent = result.message;
        feedbackDiv.className = "success";
          currentPasswordInput.value = "";
                newPasswordInput.value = "";
          confirmPasswordInput.value = "";
      } else {
        feedbackDiv.textContent = result.message;
        feedbackDiv.className = "error";
      }
      feedbackDiv.style.display = "block";
    } catch (error) {
      console.error("Fehler beim Ändern des Passworts:", error);
    }
      setTimeout(() => {
            feedbackDiv.textContent = "";
            feedbackDiv.style = "display: none;";
        }, 5000)
  });

  // Logout-Logik
  logoutButton.addEventListener("click", async () => {
    try {
      const response = await fetch("/logout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      const result = await response.json();
      if (result.success) {
        alert(result.message);
        window.location.href = "/loginNew.html"; // Zurück zur Login-Seite
      } else {
        alert("Fehler beim Abmelden.");
      }
    } catch (error) {
      console.error("Fehler beim Logout:", error);
    }
  });
});
