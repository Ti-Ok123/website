document.addEventListener("DOMContentLoaded", async () => {
  const profileButton = document.getElementById("profileButton");
  const libraryButton = document.getElementById("libraryButton");

  if (!profileButton) {
    console.log("Kein 'profileButton' gefunden. Authentifizierungslogik wird übersprungen.");
    return;
  }

  try {
    // Login-Status abfragen
    const response = await fetch("/status", {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    const status = await response.json();

    if (status.logged_in) {
      // Benutzer ist eingeloggt -> Profil anzeigen
      profileButton.textContent = `Profil (${status.username})`;
      profileButton.addEventListener("click", () => {
        window.location.href = "/profile.html";
      });
    } else {
      // Benutzer ist nicht eingeloggt -> Anmelden anzeigen
      profileButton.textContent = "Anmelden";
      profileButton.addEventListener("click", () => {
        window.location.href = "/loginNew.html";
      });
    }
  } catch (error) {
    console.error("Fehler beim Abrufen des Login-Status:", error);
  }

    try {
    // Login-Status abfragen
    const response = await fetch("/premium", {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    const premium = await response.json();

    if (premium.premium == 1) {
      // Benutzer hat Premium -> library anzeigen
      libraryButton.addEventListener("click", () => {
        window.location.href = "/library.html";
      });
    } else if(premium.premium == 2) {
        libraryButton.addEventListener("click", () => {
        window.location.href = "/loginNew.html";
        alert("Bitte anmelden bevor du auf die Library zugreifst")
      });
    } else {
      // Benutzer hat kein Premium -> Kauf anzeigen
      libraryButton.addEventListener("click", () => {
        window.location.href = "/premium.html";

      });
    }
  } catch (error) {
    console.error("Fehler beim Abrufen des Login-Status:", error);
  }
});
