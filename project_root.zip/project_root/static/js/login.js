document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");

  // Login-Formular-Logik
  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;

      try {
        const response = await fetch("/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password }),
        });

        const result = await response.json();

        if (result.success) {
          alert(result.message);
          window.location.href = "/index.html"; // Zurück zur Startseite
        } else {
          alert(result.message);
        }
      } catch (error) {
        console.error("Fehler beim Login:", error);
      }
    });
  }

  // Registrierungs-Formular-Logik
  if (registerForm) {
    registerForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const username = document.getElementById("newUsername").value;
      const password = document.getElementById("newPassword").value;

      try {
        const response = await fetch("/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password }),
        });

        const result = await response.json();

        if (result.success) {
          alert(result.message);
          window.location.href = "/index.html"; // Zurück zur Startseite
        } else {
          alert(result.message);
        }
      } catch (error) {
        console.error("Fehler bei der Registrierung:", error);
      }
    });
  }
});
