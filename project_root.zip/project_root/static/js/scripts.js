document.addEventListener("DOMContentLoaded", () => {
  console.log("Website Loaded");
});
